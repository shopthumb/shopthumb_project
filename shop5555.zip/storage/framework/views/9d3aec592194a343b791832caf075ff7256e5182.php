<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Shopacus</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Your page description here" />
    <meta name="author" content="" />

    <!-- css -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

    <link href="css/style.css" rel="stylesheet" type="text/css" />

    <link href="css/bootstrap-colorselector.min.css" rel="stylesheet" type="text/css" />


    <!-- Fav and touch icons -->
    <link rel="shortcut icon" href="ico/favicon.png" />

    <!-- =======================================================
    Theme Name: Eterna
    Theme URL: https://bootstrapmade.com/eterna-free-multipurpose-bootstrap-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="0">

    <div id="wrapper">

        <!-- start header -->
        <header data-spy="affix" data-offset-top="197">

            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="logo text-center">
                            <a href="#" style="text-decoration: none;">
                                <h1>SHOPACUS</h1>
                            </a>
                        </div>

                        <div class="pull-right hidden-xs">
                            <p class="login-register"><span class="ac-section"><a href="#">Login</a> / <a href="#">Register</a></span>
                                <span class="fav-section"><a href="#"><i class="far fa-heart"></i></a></span> 
                                <a href="#"><img src="img/flag.jpg" alt="Flag"></a>
                            </p>
                        </div>
                    </div>


                </div>
            </div>

            <div class="top">
                <div class="container">
                    <div class="row nomargin">
                        <div class="col-md-8">
                            <div class="pull-left hidden-md hidden-lg text-left">
                                <p class="login-register"><span class="ac-section"><a href="#">Login</a> / <a href="#">Register</a></span>
                                    <span class="fav-section"><i class="far fa-heart"></i></span> <img src="img/flag.jpg" alt="Flag">
                                </p>
                            </div>
                            <nav class="navbar navbar-inverse" id="ddmenu">


                                <div class="menu-icon"></div>
                                <ul class="text-center">
                                    <li>
                                        <span>Women</span>
                                        <div class="dropdown">
                                            <div class="dd-inner">
                                                <ul class="column">
                                                    <li>
                                                        <h3>DESIGNERS</h3>
                                                    </li>
                                                    <li><a href="#">All Designers (A-Z)</a></li>
                                                    <li><a href="#">Ulla Johnson</a></li>
                                                    <li><a href="#">Saint Laurent</a></li>
                                                    <li><a href="#">Givenchy</a></li>
                                                    <li><a href="#">Nili Lotan</a></li>
                                                    <li><a href="#">Isabel Marant</a></li>
                                                    <li><a href="#">Paco Rabanne</a></li>
                                                    <li><a href="#">Maison Mayle</a></li>
                                                    <li><a href="#">Gianvito Rossi</a></li>

                                                </ul>
                                                <ul class="column">
                                                    <li>
                                                        <h3>CLOTHING</h3>
                                                    </li>
                                                    <li><a href="#">Skirts</a></li>
                                                    <li><a href="#">Sweaters</a></li>
                                                    <li><a href="#">Coats/ Jackets</a></li>
                                                    <li><a href="#">Dresses</a></li>
                                                    <li><a href="#">Shorts</a></li>

                                                    <li><a href="#">Activewear</a></li>
                                                    <li><a href="#">Pants</a></li>
                                                    <li><a href="#">Tops</a></li>
                                                    <li><a href="#">Jeans</a></li>
                                                    <li><a href="#">Jumpsuits/Rompers</a></li>
                                                    <li><a href="#">Maternity</a></li>
                                                    <li><a href="#">Lingerie</a></li>
                                                    <li><a href="#">Swimwear</a></li>

                                                </ul>
                                                <ul class="column mayHide">
                                                    <li>
                                                        <h3>SHOES</h3>
                                                    </li>
                                                    <li><a href="#">Ballet</a></li>
                                                    <li><a href="#">Sneakers</a></li>
                                                    <li><a href="#">Sandals</a></li>
                                                    <li><a href="#">Loafers & Oxfords</a></li>
                                                    <li><a href="#">Platforms</a></li>

                                                    <li><a href="#">Espadrilles</a></li>
                                                    <li><a href="#">Slingbacks</a></li>
                                                    <li><a href="#">Pumps</a></li>
                                                    <li><a href="#">Boots</a></li>
                                                    <li><a href="#">Booties</a></li>
                                                    <li><a href="#">Wedges</a></li>
                                                    <li><a href="#">Mules & Clogs</a></li>
                                                    <li><a href="#">Mary-Jane</a></li>
                                                    <li><a href="#">Flats</a></li>
                                                    <li><a href="#">Rain Boots</a></li>
                                                    <li><a href="#">Shoe Accessories</a></li>
                                                    <li><a href="#">Trend: Block Heels</a></li>
                                                </ul>
                                                <ul class="column mayHide">
                                                    <li>
                                                        <h3>BAGS</h3>
                                                    </li>
                                                    <li><a href="#">Totes</a></li>
                                                    <li><a href="#">Duffels</a></li>
                                                    <li><a href="#">Baby Bags</a></li>
                                                    <li><a href="#">Backpacks</a></li>
                                                    <li><a href="#">Bucket</a></li>

                                                    <li><a href="#">Beach</a></li>
                                                    <li><a href="#">Cosmetic pouches</a></li>
                                                    <li><a href="#">Cross-body</a></li>
                                                    <li><a href="#">Hobo</a></li>
                                                    <li><a href="#">Messengers</a></li>
                                                    <li><a href="#">Tech Accessories</a></li>
                                                    <li><a href="#">Saddle</a></li>
                                                    <li><a href="#">Keychains</a></li>
                                                    <li><a href="#">Mini</a></li>
                                                    <li><a href="#">Travel</a></li>
                                                    <li><a href="#">Clutches</a></li>
                                                    <li><a href="#">Shoulder</a></li>
                                                    <li><a href="#">Wallets</a></li>
                                                    <li><a href="#">Bag Accessories</a></li>
                                                </ul>
                                                <ul class="column mayHide">
                                                    <li>
                                                        <h3>ACCESSORIES</h3>
                                                    </li>
                                                    <li><a href="#">Belts</a></li>
                                                    <li><a href="#">Scarves</a></li>
                                                    <li><a href="#">Gloves</a></li>
                                                    <li><a href="#">Sunglasses & Eyewear</a></li>
                                                    <li><a href="#">Hats</a></li>

                                                    <li><a href="#">Watches</a></li>
                                                    <li><a href="#">Socks/ Tights</a></li>
                                                    <li><a href="#">Umbrella</a></li>
                                                    <li><a href="#">Hair accessories</a></li>
                                                    <li><a href="#">Pool Party</a></li>
                                                    <li><a href="#">Active accessories</a></li>
                                                    <li><a href="#">Jewelry</a></li>
                                                    <li><a href="#">Fine Jewelry</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="no-sub"><a class="top-heading" href="#">Men</a></li>
                                    <li>
                                        <a href="http://www.microsoft.com">Beauty</a>

                                        <div class="dropdown">
                                            <div class="dd-inner">
                                                <ul class="column">
                                                    <li>
                                                        <h3>DESIGNERS</h3>
                                                    </li>
                                                    <li><a href="#">All Designers (A-Z)</a></li>
                                                    <li><a href="#">Ulla Johnson</a></li>
                                                    <li><a href="#">Saint Laurent</a></li>
                                                    <li><a href="#">Givenchy</a></li>
                                                    <li><a href="#">Nili Lotan</a></li>
                                                    <li><a href="#">Isabel Marant</a></li>
                                                    <li><a href="#">Paco Rabanne</a></li>
                                                    <li><a href="#">Maison Mayle</a></li>
                                                    <li><a href="#">Gianvito Rossi</a></li>

                                                </ul>
                                                <ul class="column">
                                                    <li>
                                                        <h3>CLOTHING</h3>
                                                    </li>
                                                    <li><a href="#">Skirts</a></li>
                                                    <li><a href="#">Sweaters</a></li>
                                                    <li><a href="#">Coats/ Jackets</a></li>
                                                    <li><a href="#">Dresses</a></li>
                                                    <li><a href="#">Shorts</a></li>

                                                    <li><a href="#">Activewear</a></li>
                                                    <li><a href="#">Pants</a></li>
                                                    <li><a href="#">Tops</a></li>
                                                    <li><a href="#">Jeans</a></li>
                                                    <li><a href="#">Jumpsuits/Rompers</a></li>
                                                    <li><a href="#">Maternity</a></li>
                                                    <li><a href="#">Lingerie</a></li>
                                                    <li><a href="#">Swimwear</a></li>

                                                </ul>
                                                <ul class="column mayHide">
                                                    <li>
                                                        <h3>SHOES</h3>
                                                    </li>
                                                    <li><a href="#">Ballet</a></li>
                                                    <li><a href="#">Sneakers</a></li>
                                                    <li><a href="#">Sandals</a></li>
                                                    <li><a href="#">Loafers & Oxfords</a></li>
                                                    <li><a href="#">Platforms</a></li>

                                                    <li><a href="#">Espadrilles</a></li>
                                                    <li><a href="#">Slingbacks</a></li>
                                                    <li><a href="#">Pumps</a></li>
                                                    <li><a href="#">Boots</a></li>
                                                    <li><a href="#">Booties</a></li>
                                                    <li><a href="#">Wedges</a></li>
                                                    <li><a href="#">Mules & Clogs</a></li>
                                                    <li><a href="#">Mary-Jane</a></li>
                                                    <li><a href="#">Flats</a></li>
                                                    <li><a href="#">Rain Boots</a></li>
                                                    <li><a href="#">Shoe Accessories</a></li>
                                                    <li><a href="#">Trend: Block Heels</a></li>
                                                </ul>

                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <span>Home</span>
                                    </li>
                                    <li class="no-sub">
                                        <a class="top-heading" href="#">Kids</a>
                                    </li>
                                    
                                </ul>
                            </nav>
                        </div>
                        <div class="col-md-4">
                            <div class="search-clm">
                                        <div class="topsearch-c">
                                            <div class="input-append">
                                                    <i class="icon-search"></i>
                                                <input class="span2" id="appendedInputButton" type="text" placeholder="Search">
                                            </div>
                                        </div>
                                    </div>
                        </div>

                    </div>
                </div>
            </div>
        </header>
        <!-- end header -->

        <section id="inner-headline">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-xs-12 text-center text-xs-center">

                        <ul class="breadcrumb">
                            <li><a href="#">Women </a> </li>
                            <li class="active"><a href="#"> Clothing </a></li>
                            <li class="active"> Tops</li>
                        </ul>
                    </div>
                    <div class="col-md-9">
                        <div class="form-group pull-right">
                            <ul class="list-style">
                                <li>
                                    <select class="form-control select-list1" id="sel1">
                                        <option>Store</option>
                                        <option>Store</option>
                                    </select>
                                </li>
                                <li>
                                    <select class="form-control select-list1" id="sel1">
                                        <option>Brand</option>
                                        <option>Store</option>
                                    </select>
                                </li>
                                <li>

                                    <select class="form-control select-list1" id="sel1">
                                        <option>Color</option>
                                        <option>Store</option>
                                    </select>
                                </li>
                                <li>

                                    <select class="form-control select-list1" id="sel1">
                                        <option>Size</option>
                                        <option>Store</option>
                                    </select>
                                </li>

                                <li>

                                    <select class="form-control select-list1" id="sel1">
                                        <option>Price</option>
                                        <option>Store</option>
                                    </select>
                                </li>

                                <li>

                                    <select class="form-control select-list1" id="sel1">
                                        <option>Deal</option>
                                        <option>Store</option>

                                    </select>

                                </li>

                                <li>

                                    <select class="form-control select-list1" id="sel1">
                                        <option>Condition</option>
                                        <option>Store</option>

                                    </select>

                                </li>

                                <li>

                                    <select class="form-control select-list1" id="sel1">
                                        <option>Newest</option>
                                        <option>Newest</option>

                                    </select>

                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <section id="content">
            <div class="container">
                <div class="row">

                    <div class="col-md-2">

                        <aside class="left-sidebar" data-spy="affix" data-offset-top="0">
                            <div class="widget">

                                <ul class="cat">
                                    <li><a href="#" style="text-decoration: underline">All</a></li>
                                    <li><a href="#">Blouses</a></li>
                                    <li><a href="#"> Bodysuits</a></li>
                                    <li><a href="#">Button Down Shirts</a></li>
                                    <li><a href="#">Camis</a></li>
                                    <li><a href="#">Crop Tops</a></li>
                                    <li><a href="#">Graphic Tees</a></li>
                                    <li><a href="#">Night Out</a></li>
                                    <li><a href="#">Off the Shoulder Tops</a></li>
                                    <li><a href="#">Sweatshirts / Hoodies</a></li>
                                    <li><a href="#">Tank Tops</a></li>
                                    <li><a href="#">Short Sleeve Tees</a></li>
                                    <li><a href="#">Long Sleeve Tees</a></li>
                                    <li><a href="#">Tunics</a></li>
                                    <li><a href="#">Turtlenecks</a></li>


                                </ul>
                            </div>

                        </aside>
                    </div>
                    <div class="col-md-10">
                        <div class="container-fluid">

                            <div class="row">

                                <div class="col-md-12 text-right">
                                    <ul style="list-style: none">
                                        <li>
                                            <nav aria-label="Page navigation example pull-right" style="float:right">
                                                <ul class="pagination pagination-sm">
                                                    <li style="padding-top: 5px;">
                                                        View&nbsp;
                                                    </li>
                                                    <li>
                                                        &nbsp;
                                                    </li>
                                                    <li class="page-item" style="float:left">
                                                        <a class="page-link" href="#">&nbsp; All &nbsp;
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="page-link" href="#"> 100
                                                        </a>
                                                    </li>
                                                    <li class="page-item" style="padding-top: 5px;">
                                                        &nbsp; Page &nbsp;
                                                    </li>
                                                    <li class="page-item">
                                                        <a class="page-link" href="#">2
                                                        </a>
                                                    </li>
                                                    <li>
                                                        &nbsp;
                                                    </li>

                                                    <li class="page-item"><a class="page-link" href="#"> <i class="fa fa-angle-left"></i></a></li>
                                                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                                                    <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                                    <li class="page-item"><a class="page-link" href="#">...</a></li>
                                                    <li class="page-item"><a class="page-link" href="#">99</a></li>
                                                    <li class="page-item"><a class="page-link" href="#">100</a></li>
                                                    <li class="page-item"><a class="page-link" href="#"><i class="fa fa-angle-right"></i></a></li>


                                                </ul>
                                            </nav>
                                        </li>
                                    </ul>


                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt  border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/img1.jpg" class="img-responsive img-fluid" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b> <a href="#">Petersyn</a> </b></div>
                                                <div class="text-left"><small> Astor Blouse </small></div>

                                                <div><span class="pull-left"><small>$158</small></span> <span class="pull-right">
                                                        <i class="far fa-heart" id="myBtn"></i>

                                                        <!-- Modal -->

                                                        <!-- Modal -->


                                                    </span>
                                                </div>
                                            </div>

                                            <div id="myModal" class="modal">
                                                <!-- Modal content -->
                                                <div class="modal-content">
                                                    <span class="close"><img src="img/close-button.svg" witdt="16px" height="16px" /></span>
                                                    <p><b>COLOR: </b> <span id="colorselectors">
                                                            <select id="colorselector_1">
                                                                <option value="106" data-color="#A0522D">sienna</option>
                                                                <option value="47" data-color="#CD5C5C" selected="selected">indianred</option>
                                                                <option value="87" data-color="#FF4500">orangered</option>
                                                                <option value="17" data-color="#008B8B">darkcyan</option>
                                                            </select>
                                                        </span></p>
                                                    <p><b>SIZE:</b> <span class="sizes">xxs </span> <span class="sizes">xxs </span> <span class="sizes">m </span> <span class="sizes">l </span> <span class="sizes">s </span></p>
                                                    <p><span class="buynow pull-left">Buy Now</span>
                                                        <span class="addtocart pull-right">Add To <i class="fas fa-heart"></i></span> </p>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/img2.jpg" class="img-responsive img-fluid" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Petersyn</a></b></div>
                                                <div class="text-left"><small>Willa Blouse</small></div>

                                                <div><span class="pull-left"><small>$158</small></span> <span class="pull-right">
                                                        <i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6  text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/img3.jpg" alt="" />

                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Me to We</a></b></div>
                                                <div class="text-left"><small>Criss-cross ribbed t-shirt</small></div>
                                                <div><span class="pull-left"><small>$24.95</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6  text-center">
                                    <div class="product-cnt">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/gucci.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Gucci</a></b></div>
                                                <div class="text-left"><small>Pussy-bow printed silk </small></div>

                                                <div><span class="pull-left"><small>$1,390</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/club-macho.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Club Monaco</a></b></div>
                                                <div class="text-left"><small>Mackenzie Merino Sweater</small></div>

                                                <div><span class="pull-left"><small>$89</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/Plenty.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Plenty by Tracy Reese</a></b></div>
                                                <div class="text-left"><small>Victoria Lace Tunic</small></div>

                                                <div><span class="pull-left"><small>$198</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/helmut-lan.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Helmut Lang</a></b></div>
                                                <div class="text-left"><small>Shrunken t-shirt</small></div>

                                                <div><span class="pull-left"><small>$160</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/Img4.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Free People</a></b></div>
                                                <div class="text-left"><small>So Much Fun Cami</small></div>
                                                <div><span class="pull-left"><small>$68</small></span> <span class="pull-right">
                                                        <i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/Wilfred.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Wilfred Free</a></b></div>
                                                <div class="text-left"><small>Bellucci Bodysuit</small></div>
                                                <div><span class="pull-left"><small>$50</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/r13.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">R13</a></b></div>
                                                <div class="text-left"><small>Love V Tee</small></div>
                                                <div><span class="pull-left"><small>$158</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-heading">
                                            <small>Free shipping over $150 + 4% cashback</small>
                                        </div>
                                        <img src="img/prince-peter.jpg" alt="" />
                                        <div class="container-desp">
                                            <div class="text-left"><b><a href="#">Prince Peter</a></b></div>
                                            <div class="text-left"><small>Rock n Roll Tee </small></div>
                                            <div><span class="pull-left"><small>$60</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt">
                                        <div class="post-heading">
                                            <small>Free shipping & free returns + 3% cashback</small>
                                        </div>
                                        <img src="img/lyantop.jpg" alt="" />
                                        <div class="container-desp">
                                            <div class="text-left"><b><a href="#">A. P. C.</a></b></div>
                                            <div class="text-left"><small>Lynn Top</small></div>
                                            <div><span class="pull-left"><small>$180.50</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/club-macho2.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Club Monaco</a></b></div>
                                                <div class="text-left"><small>Orsalla Top</small></div>
                                                <div><span class="pull-left"><small>$245.50</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/tibi.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Tibi</a></b></div>
                                                <div class="text-left"><small>Carmen off-the-shoulder </small></div>
                                                <div><span class="pull-left"><small>$395</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>4% cashback</small>
                                            </div>
                                            <img src="img/truly.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Truly Madly Deeply</a></b></div>
                                                <div class="text-left"><small>Gigi Pullover Sweatshirt</small></div>
                                                <div><span class="pull-left"><small>$49</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping + 3% cashback</small>
                                            </div>
                                            <img src="img/balenco.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Balenciaga</a></b></div>
                                                <div class="text-left"><small>Tieneck Crepe Drop-shoulder</small></div>
                                                <div><span class="pull-left"><small>$1,045</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-3 col-xs-6 text-center ">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/silence.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Silence + Noise</a></b></div>
                                                <div class="text-left"><small>Shell Tank Top</small></div>
                                                <div><span class="pull-left"><small>$49.50</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping & free returns + 2% cashback</small>
                                            </div>
                                            <img src="img/jcrew.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">J. Crew</a></b></div>
                                                <div class="text-left"><small>Vintage Red-plaid Boyfriend </small></div>
                                                <div><span class="pull-left"><small>$89.50</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="product-cnt border-right">
                                        <div class="post-image">
                                            <div class="post-heading">
                                                <small>Free shipping over $150 + 4% cashback</small>
                                            </div>
                                            <img src="img/jcrew2.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">J.Crew</a></b></div>
                                                <div class="text-left"><small>‘Edie’ Ruffle Top</small></div>
                                                <div><span class="pull-left"><small>$59.50</small></span> <span class="pull-right"><i class="far fa-heart"></i></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-6 text-center">
                                    <div class="post-image">
                                        <div class="product-cnt">
                                            <div class="post-heading">
                                                <small>Free shipping + 3% cashback</small>
                                            </div>
                                            <img src="img/madewell.jpg" alt="" />
                                            <div class="container-desp">
                                                <div class="text-left"><b><a href="#">Madewell</a></b></div>
                                                <div class="text-left"><small>Flannel Ex-boyfriend Shirt</small></div>
                                                <div><span class="pull-left"><small><strike>$79.50</strike> <b>$59.50</b></small></span> <span class="pull-right"><i class="far fa-heart" data-toggle="modal" data-target="#exampleModal"></i></span></div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">

                                <div class="col-md-12 text-right">
                                    <ul style="list-style: none">
                                        <li>
                                            <nav aria-label="Page navigation example pull-right" style="float:right">
                                                <ul class="pagination pagination-sm">
                                                    <li style="padding-top: 5px;">
                                                        View&nbsp;
                                                    </li>
                                                    <li>
                                                        &nbsp;
                                                    </li>
                                                    <li class="page-item" style="float:left">
                                                        <a class="page-link" href="#">&nbsp; All &nbsp;
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="page-link" href="#"> 100
                                                        </a>
                                                    </li>
                                                    <li class="page-item" style="padding-top: 5px;">
                                                        &nbsp; Page &nbsp;
                                                    </li>
                                                    <li class="page-item">
                                                        <a class="page-link" href="#">2
                                                        </a>
                                                    </li>
                                                    <li>
                                                        &nbsp;
                                                    </li>

                                                    <li class="page-item"><a class="page-link" href="#"> &laquo;</a></li>
                                                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                                                    <li class="page-item active"><a class="page-link" href="#">2</a></li>
                                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                                    <li class="page-item"><a class="page-link" href="#">...</a></li>
                                                    <li class="page-item"><a class="page-link" href="#">15</a></li>
                                                    <li class="page-item"><a class="page-link" href="#"> &raquo;</a></li>


                                                </ul>
                                            </nav>
                                        </li>
                                    </ul>


                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </section>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="widget">
                            <h5 class="widgetheading">About ShopThumb</h5>
                            <ul class="link-list">
                                <li><a href="#">Our Story</a></li>
                                <li><a href="#">How ShopThumb works</a></li>
                                <li><a href="#">Careers</a></li>
                                <li><a href="#">Affiliates</a></li>
                                <li><a href="#">Advertising</a></li>
                                <li><a href="#">Sitemap</a></li>
                                <li><a href="#">Press</a></li>
                            </ul>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="widget">
                            <h5 class="widgetheading">CUSTOMER SERVICE</h5>
                            <ul class="link-list">
                                <li><a href="#">Contact Us</a></li>
                                <li><a href="#">FAQ</a></li>
                                <li><a href="#">Terms of use</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Brand Directory</a></li>
                                <li><a href="#">Store Directory</a></li>
                                <li><a href="#">Top Searches</a></li>
                                <li><a href="#">Quick Links</a></li>
                                <li><a href="#">Feedback</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 text-center">
                        <div class="widget">
                            <h5 class="widgetheading">Stay in Touch</h5>
                            <p>
                                Receive offers & updates:
                            </p>
                            <form class="subscribe">
                                <div class="input-append2">
                                    <input class="span2" id="appendedInputButton" type="text" placeholder="Your email">
                                    <button class="btn btn-theme" type="submit"><i class="icon-arrow-right"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <h5 class="widgetheading">Connect</h5>
                        <ul class="link-list">
                            <li><a href="#"><i class="icon-1x icon-facebook-sign"> </i>Facebook</a></li>
                            <li><a href="#"><i class="icon-1x icon-twitter-sign"> </i> Twitter</a></li>
                            <li><a href="#"><i class="icon-1x icon-pinterest"> </i> Pinterest</a></li>
                            <li><a href="#"><i class="icon-1x icon-instagram"> </i> Instagram</a></li>
                        </ul>
                        <br />
                        <h5 class="widgetheading">DOWNLOAD OUR APPS</h5>
                        <ul class="link-list">
                            <li><a href="#"><i class="icon-1x icon-apple"> </i>iphone app</a></li>
                            <li><a href="#"><i class="icon-1x icon-android"> </i> android app</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div id="sub-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="copyright">
                                <p><span>&copy; 2019 ShopThumb</span></p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <a href="#" class="scrollup"><i class="icon-angle-up icon-square icon-bglight icon-2x active"></i></a>




    <!-- javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/modernizr.custom.js"></script>

    <script src="js/animate.js"></script>

    <script src="js/ddmenu.js"></script>
    <script src="js/bootstrap-colorselector.min.js"></script>


    <script>
        
        $(window).scroll(function() {
    var height = $(window).scrollTop();
    if (height > 400) {
        $('.scrollup').fadeIn();
    } else {
        $('.scrollup').fadeOut();
    }
});
$(document).ready(function() {
    $(".scrollup").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

});
        
        
        // Get the modal
        var modal = document.getElementById('myModal');

        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks the button, open the modal 
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

    </script>

    <script>
        $(function() {

            window.prettyPrint && prettyPrint();

            $('#colorselector_1').colorselector();
            $('#colorselector_2').colorselector({
                callback: function(value, color, title) {
                    $("#colorValue").val(value);
                    $("#colorColor").val(color);
                    $("#colorTitle").val(title);
                }
            });

            $("#setColor").click(function(e) {
                $("#colorselector_2").colorselector("setColor", "#008B8B");
            })

            $("#setValue").click(function(e) {
                $("#colorselector_2").colorselector("setValue", 18);
            })

        });

    </script>


</body>

</html>
