<?php 
include('db.php');


$countSql = "SELECT COUNT(id) FROM product";  
$tot_result = mysqli_query($conn, $countSql);   
$row = mysqli_fetch_row($tot_result);  
$total_records = $row[0];  
$total_pages = ceil($total_records / $limit);

//for first time load data
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
$start_from = ($page-1) * $limit;  
$sql = "SELECT * FROM product ORDER BY id ASC LIMIT $start_from, $limit";  
$rs_result = mysqli_query($conn, $sql); 

$data='';
 $i=1;
$data='<div class="row">';
while ($row = mysqli_fetch_assoc($rs_result)) 
{
    //echo $row["id"];
    $image1 = "product_image/".$row["image1"];
    $product_brand = $row["product_brand"];
    $product_price = $row["product_price"];
    $product_title = $row["product_title"];
    $long_description = $row["long_description"];

    if($i%4==0)
    {       $data.='<div class="col-md-3 col-xs-6 text-center">
                <div class="product-cnt  border-right">
                    <div class="post-image">
                        <div class="post-heading">
                            <small>Free shipping & free returns + 2% cashback</small>
                        </div>
                        <img src='.$image1.' class="img-responsive img-fluid" alt="" width="175" />
                        <div class="container-desp">
                            <div class="text-left"><b> <a href="#">'.$product_brand.'</a> </b></div>
                            <div class="text-left"><small>'.$product_title.'</small></div>

                            <div><span class="pull-left"><small>'.$product_price.'</small></span> <span class="pull-right">
                                    <i class="far fa-heart" id="myBtn"></i>
                                </span>
                            </div>
                        </div>

                        <div id="myModal" class="modal">
                            <!-- Modal content -->
                            <div class="modal-content">
                                <span class="close"><img src="img/close-button.svg" witdt="16px" height="16px" /></span>
                                <p><b>COLOR: </b> <span id="colorselectors">
                                        <select id="colorselector_1">
                                            <option value="106" data-color="#A0522D">sienna</option>
                                            <option value="47" data-color="#CD5C5C" selected="selected">indianred</option>
                                            <option value="87" data-color="#FF4500">orangered</option>
                                            <option value="17" data-color="#008B8B">darkcyan</option>
                                        </select>
                                    </span></p>
                                <p><b>SIZE:</b> <span class="sizes">xxs </span> <span class="sizes">xxs </span> <span class="sizes">m </span> <span class="sizes">l </span> <span class="sizes">s </span></p>
                                <p><span class="buynow pull-left">Buy Now</span>
                                    <span class="addtocart pull-right">Add To <i class="fas fa-heart"></i></span> </p>
                            </div>
                        </div>
                    </div>
                </div>
                </div>';    
            $data.='</div><div class="row">';    
    }
    else
    {   $data.='<div class="col-md-3 col-xs-6 text-center">
                <div class="product-cnt  border-right">
                    <div class="post-image">
                        <div class="post-heading">
                            <small>Free shipping & free returns + 2% cashback</small>
                        </div>
                        <img src='.$image1.' class="img-responsive img-fluid" alt="" width="175" />
                        <div class="container-desp">
                            <div class="text-left"><b> <a href="#">'.$product_brand.'</a> </b></div>
                            <div class="text-left"><small>'.$product_title.'</small></div>

                            <div><span class="pull-left"><small>$'.$product_price.'</small></span> <span class="pull-right">
                                    <i class="far fa-heart" id="myBtn"></i>
                                </span>
                            </div>
                        </div>

                        <div id="myModal" class="modal">
                            <!-- Modal content -->
                            <div class="modal-content">
                                <span class="close"><img src="img/close-button.svg" witdt="16px" height="16px" /></span>
                                <p><b>COLOR: </b> <span id="colorselectors">
                                        <select id="colorselector_1">
                                            <option value="106" data-color="#A0522D">sienna</option>
                                            <option value="47" data-color="#CD5C5C" selected="selected">indianred</option>
                                            <option value="87" data-color="#FF4500">orangered</option>
                                            <option value="17" data-color="#008B8B">darkcyan</option>
                                        </select>
                                    </span></p>
                                <p><b>SIZE:</b> <span class="sizes">xxs </span> <span class="sizes">xxs </span> <span class="sizes">m </span> <span class="sizes">l </span> <span class="sizes">s </span></p>
                                <p><span class="buynow pull-left">Buy Now</span>
                                    <span class="addtocart pull-right">Add To <i class="fas fa-heart"></i></span> </p>
                            </div>
                        </div>
                    </div>
                </div>
                </div>';    
    }

    $i++;     
}  



// get category and subcategory 
$cat_data='';
$sql0 = "SELECT * FROM categories where parent_id='0' ORDER BY categories_id"; 
$rs_result0 = mysqli_query($conn, $sql0); 
while ($row0 = mysqli_fetch_assoc($rs_result0)) 
{
    $categories_id = $row0["categories_id"];
    $parent_id = $row0["parent_id"];
    $categories_name = $row0["categories_name"];
    $category = "<span>".$categories_name."</span>";
    $sub_cat= getsubCategory($categories_id, $conn);

    $cat_data.='
    <li>
        <span>'.$category.'</span>
        <div class="dropdown">
            <div class="dd-inner">
                 '.$sub_cat.'
            </div>
        </div>
    </li>
    ';
} 

function getsubCategory($categories_id, $conn)
{   $dt='';
    //$sql2 = "SELECT * FROM categories where parent_id=".$categories_id." ORDER BY categories_id"; 
    $sql2 = "SELECT * FROM categories where parent_id='1' ORDER BY categories_id"; 
    $rs_result2 = mysqli_query($conn, $sql2);     
    while ($row2 = mysqli_fetch_assoc($rs_result2)) 
    {   $categories_id2 = $row2["categories_id"];
        $parent_id2 = $row2["parent_id"];
        $categories_name2 = $row2["categories_name"];

        $dt.='
            <ul class="column">
            <li>
                <h3>'.$categories_name2.'</h3>
            </li> ';

            $sql3 = "SELECT * FROM categories where parent_id=".$categories_id2." ORDER BY categories_id"; 
            $rs_result3 = mysqli_query($conn, $sql3);     
            while ($row3 = mysqli_fetch_assoc($rs_result3)) 
            {   $categories_id3 = $row3["categories_id"];
                $parent_id3 = $row3["parent_id"];
                $categories_name3 = $row3["categories_name"];
                $dt.='<li><a href="index.php?cid='.$categories_id3.'">'.$categories_name3.'</a></li>';  
            }
            $dt.='</ul>';
    }
    return $dt;
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>ShopThumb</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Your page description here" />
    <meta name="author" content="" />

    <!-- css -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

    <link href="css/style.css" rel="stylesheet" type="text/css" />

    <link href="css/bootstrap-colorselector.min.css" rel="stylesheet" type="text/css" />


    <!-- Fav and touch icons -->
    <link rel="shortcut icon" href="ico/favicon.png" />

   <script type="text/javascript">
    $(document).ready(function(){
    $('.pagination').pagination({
            items: <?php echo $total_records;?>,
            itemsOnPage: <?php echo $limit;?>,
            cssStyle: 'light-theme',
            currentPage : 1,
            onPageClick : function(pageNumber) {
                jQuery("#target-content").html('loading...');
                jQuery("#target-content").load("index.php?page=" + pageNumber);
            }
        });
    });
    </script>

</head>

<body data-spy="scroll" data-target=".navbar" data-offset="0">

    <div id="wrapper">

        <!-- start header -->
        <header data-spy="affix" data-offset-top="197">

            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="logo text-center">
                            <a href="#" style="text-decoration: none;">
                                <h1>ShopThumb</h1>
                            </a>
                        </div>

                        <div class="pull-right hidden-xs">
                            <p class="login-register"><span class="ac-section"><a href="#">Login</a> / <a href="#">Register</a></span>
                                <span class="fav-section"><a href="#"><i class="far fa-heart"></i></a></span> 
                                <a href="#"><img src="img/flag.jpg" alt="Flag"></a>
                            </p>
                        </div>
                    </div>


                </div>
            </div>

            <div class="top">
                <div class="container">
                    <div class="row nomargin">
                        <div class="col-md-8">
                            <div class="pull-left hidden-md hidden-lg text-left">
                                <p class="login-register"><span class="ac-section"><a href="#">Login</a> / <a href="#">Register</a></span>
                                    <span class="fav-section"><i class="far fa-heart"></i></span> <img src="img/flag.jpg" alt="Flag">
                                </p>
                            </div>
                            <nav class="navbar navbar-inverse" id="ddmenu">
                                <div class="menu-icon"></div>
                                <ul class="text-center">
                                <?php echo $cat_data; ?>    
                                </ul>
                            </nav>
                        </div>
                        <div class="col-md-4">
                            <div class="search-clm">
                                        <div class="topsearch-c">
                                            <div class="input-append">
                                                    <i class="icon-search"></i>
                                                <input class="span2" id="appendedInputButton" type="text" placeholder="Search">
                                            </div>
                                        </div>
                                    </div>
                        </div>

                    </div>
                </div>
            </div>
        </header>
        <!-- end header -->

        <section id="inner-headline">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-xs-12 text-center text-xs-center">

                        <ul class="breadcrumb">
                            <li><a href="#">Women </a> </li>
                            <li class="active"><a href="#"> Clothing </a></li>
                            <li class="active"> Tops</li>
                        </ul>
                    </div>
                    <div class="col-md-9">
                        <div class="form-group pull-right">
                            <ul class="list-style">
                                <li>
                                    <select class="form-control select-list1" id="sel1">
                                        <option>Store</option>
                                        <option>Store</option>
                                    </select>
                                </li>
                                <li>
                                    <select class="form-control select-list1" id="sel1">
                                        <option>Brand</option>
                                        <option>Splits59</option>
                                        <option>Phat Buddha</option>
                                        <option>The Upside</option>
                                        <option>Onzie</option>
                                        <option>Y-3</option>
                                        <option>Terez</option>
                                        <option>RtA</option>
                                        <option>Perfect Moment</option>
                                        <option>ALALA</option>
                                        <option>P.E NATION</option>
                                        <option>Ultracor</option>
                                        <option>Heroine Sport</option>
                                        <option>Kappa</option>
                                        <option>Tory Sport</option>
                                        <option>adidas Originals by Alexander Wang</option>
                                        <option>Beyond Yoga</option>
                                        <option>adidas by Stella McCartney</option>
                                        <option>Spiritual Gangster</option>
                                    </select>
                                </li>
                                <li>

                                    <select class="form-control select-list1" id="sel1">
                                        <option>Color</option>
                                        <option>Store</option>
                                    </select>
                                </li>
                                <li>

                                    <select class="form-control select-list1" id="sel1">
                                        <option>Size</option>
                                        <option>Store</option>
                                    </select>
                                </li>

                                <li>

                                    <select class="form-control select-list1" id="sel1">
                                        <option>Price</option>
                                        <option>$1 - $25</option>
                                        <option>$25 - $50</option>
                                        <option>$50 - $75</option>
                                        <option>$75 - $100</option>
                                        <option>$100 - $125</option>
                                        <option>$125 - $150</option>
                                        <option>$150 - $175</option>
                                        <option>$175 - $200</option>
                                    </select>
                                </li>

                                <li>
                                    <select class="form-control select-list1" id="sel1">
                                        <option>Deal</option>
                                        <option>Store</option>
                                    </select>
                                </li>

                                <li>
                                    <select class="form-control select-list1" id="sel1">
                                        <option>Condition</option>
                                        <option>Store</option>
                                    </select>
                                </li>
                                <li>
                                    <select class="form-control select-list1" id="sel1">
                                        <option>Newest</option>
                                        <option>Newest</option>
                                    </select>

                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <section id="content">
            <div class="container">
                <div class="row">

                    <div class="col-md-2">

                        <aside class="left-sidebar" data-spy="affix" data-offset-top="0">
                            <div class="widget">

                                <ul class="cat">
                                    <li><a href="#" style="text-decoration: underline">All</a></li>
                                    <li><a href="#">Blouses</a></li>
                                    <li><a href="#"> Bodysuits</a></li>
                                    <li><a href="#">Button Down Shirts</a></li>
                                    <li><a href="#">Camis</a></li>
                                    <li><a href="#">Crop Tops</a></li>
                                    <li><a href="#">Graphic Tees</a></li>
                                    <li><a href="#">Night Out</a></li>
                                    <li><a href="#">Off the Shoulder Tops</a></li>
                                    <li><a href="#">Sweatshirts / Hoodies</a></li>
                                    <li><a href="#">Tank Tops</a></li>
                                    <li><a href="#">Short Sleeve Tees</a></li>
                                    <li><a href="#">Long Sleeve Tees</a></li>
                                    <li><a href="#">Tunics</a></li>
                                    <li><a href="#">Turtlenecks</a></li>


                                </ul>
                            </div>

                        </aside>
                    </div>
                    <div class="col-md-10">
                        <div class="container-fluid">

                            <div class="row">

                                <div class="col-md-12 text-right">
                                    <ul style="list-style: none">
                                        <li>
                                            <nav aria-label="Page navigation example pull-right" style="float:right">
                                        
                                                <ul class="pagination pagination-sm">
                                                <li style="padding-top: 5px;">
                                                    View&nbsp;
                                                </li>
                                                <li>&nbsp;</li>
                                                <li class="page-item" style="float:left">
                                                    <a class="page-link" href="#">&nbsp; All &nbsp; </a>
                                                </li>
                                                <li><a class="page-link" href="#"> <?php echo $total_pages?> </a>
                                                </li>
                                                <li class="page-item" style="padding-top: 5px;">&nbsp; Page &nbsp; </li>
                                                <li class="page-item"> <a class="page-link" href="#"><?php echo $page; ?> </a> <!-- current page selected  -->
                                                </li><li> &nbsp;  </li>

                                                <?php if(!empty($total_pages)):for($i=1; $i<=$total_pages; $i++):  
                                                        if($i == $page):?>
                                                        <li class='page-item active'  id="<?php echo $i;?>"><a class="page-link" href='index.php?page=<?php echo $i;?>'><?php echo $i;?></a></li> 
                                                        <?php else:?>
                                                        <li class="page-item" id="<?php echo $i;?>"><a class="page-link" href='index.php?page=<?php echo $i;?>'><?php echo $i;?></a></li>
                                                    <?php endif;?>          
                                            <?php endfor;endif;?>

                                                </ul>

                                            </nav>
                                        </li>
                                    </ul>


                                </div>
                            </div>

                            <?php echo $data; ?>
                            
                            <div class="row">

                                <div class="col-md-12 text-right">
                                    <ul style="list-style: none">
                                        <li>
                                            <nav aria-label="Page navigation example pull-right" style="float:right">


                                                <ul class="pagination pagination-sm">
                                                <li style="padding-top: 5px;">
                                                    View&nbsp;
                                                </li>
                                                <li>&nbsp;</li>
                                                <li class="page-item" style="float:left">
                                                    <a class="page-link" href="#">&nbsp; All &nbsp; </a>
                                                </li>
                                                <li><a class="page-link" href="#"> <?php echo $total_pages?> </a>
                                                </li>
                                                <li class="page-item" style="padding-top: 5px;">&nbsp; Page &nbsp; </li>
                                                <li class="page-item"> <a class="page-link" href="#"><?php echo $page; ?> </a> <!-- current page selected  -->
                                                </li><li> &nbsp;  </li>

                                                <?php if(!empty($total_pages)):for($i=1; $i<=$total_pages; $i++):  
                                                        if($i == $page):?>
                                                        <li class='page-item active'  id="<?php echo $i;?>"><a class="page-link" href='index.php?page=<?php echo $i;?>'><?php echo $i;?></a></li> 
                                                        <?php else:?>
                                                        <li class="page-item" id="<?php echo $i;?>"><a class="page-link" href='index.php?page=<?php echo $i;?>'><?php echo $i;?></a></li>
                                                    <?php endif;?>          
                                            <?php endfor;endif;?>

                                                </ul>
                                            </nav>
                                        </li>
                                    </ul>


                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </section>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="widget">
                            <h5 class="widgetheading">About ShopThumb</h5>
                            <ul class="link-list">
                                <li><a href="#">Our Story</a></li>
                                <li><a href="#">How ShopThumb works</a></li>
                                <li><a href="#">Careers</a></li>
                                <li><a href="#">Affiliates</a></li>
                                <li><a href="#">Advertising</a></li>
                                <li><a href="#">Sitemap</a></li>
                                <li><a href="#">Press</a></li>
                            </ul>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="widget">
                            <h5 class="widgetheading">CUSTOMER SERVICE</h5>
                            <ul class="link-list">
                                <li><a href="#">Contact Us</a></li>
                                <li><a href="#">FAQ</a></li>
                                <li><a href="#">Terms of use</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Brand Directory</a></li>
                                <li><a href="#">Store Directory</a></li>
                                <li><a href="#">Top Searches</a></li>
                                <li><a href="#">Quick Links</a></li>
                                <li><a href="#">Feedback</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 text-center">
                        <div class="widget">
                            <h5 class="widgetheading">Stay in Touch</h5>
                            <p>
                                Receive offers & updates:
                            </p>
                            <form class="subscribe">
                                <div class="input-append2">
                                    <input class="span2" id="appendedInputButton" type="text" placeholder="Your email">
                                    <button class="btn btn-theme" type="submit"><i class="icon-arrow-right"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <h5 class="widgetheading">Connect</h5>
                        <ul class="link-list">
                            <li><a href="#"><i class="icon-1x icon-facebook-sign"> </i>Facebook</a></li>
                            <li><a href="#"><i class="icon-1x icon-twitter-sign"> </i> Twitter</a></li>
                            <li><a href="#"><i class="icon-1x icon-pinterest"> </i> Pinterest</a></li>
                            <li><a href="#"><i class="icon-1x icon-instagram"> </i> Instagram</a></li>
                        </ul>
                        <br />
                        <h5 class="widgetheading">DOWNLOAD OUR APPS</h5>
                        <ul class="link-list">
                            <li><a href="#"><i class="icon-1x icon-apple"> </i>iphone app</a></li>
                            <li><a href="#"><i class="icon-1x icon-android"> </i> android app</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div id="sub-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="copyright">
                                <p><span>&copy; 2019 ShopThumb</span></p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <a href="#" class="scrollup"><i class="icon-angle-up icon-square icon-bglight icon-2x active"></i></a>




    <!-- javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/modernizr.custom.js"></script>

    <script src="js/animate.js"></script>

    <script src="js/ddmenu.js"></script>
    <script src="js/bootstrap-colorselector.min.js"></script>


    <script>
        
        $(window).scroll(function() {
    var height = $(window).scrollTop();
    if (height > 400) {
        $('.scrollup').fadeIn();
    } else {
        $('.scrollup').fadeOut();
    }
});
$(document).ready(function() {
    $(".scrollup").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

});
        
        
        // Get the modal
        var modal = document.getElementById('myModal');

        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks the button, open the modal 
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

    </script>

    <script>
        $(function() {

            window.prettyPrint && prettyPrint();

            $('#colorselector_1').colorselector();
            $('#colorselector_2').colorselector({
                callback: function(value, color, title) {
                    $("#colorValue").val(value);
                    $("#colorColor").val(color);
                    $("#colorTitle").val(title);
                }
            });

            $("#setColor").click(function(e) {
                $("#colorselector_2").colorselector("setColor", "#008B8B");
            })

            $("#setValue").click(function(e) {
                $("#colorselector_2").colorselector("setValue", 18);
            })

        });

    </script>


</body>

</html>
