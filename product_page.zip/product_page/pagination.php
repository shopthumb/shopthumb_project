<?php
include('db.php');

if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
$start_from = ($page-1) * $limit;  
  
$sql = "SELECT * FROM product ORDER BY id ASC LIMIT $start_from, $limit";  
$rs_result = mysqli_query($conn, $sql); 
?>


$data='';
 $i=1;
$data='<div class="row">';
while ($row = mysqli_fetch_assoc($rs_result)) 
{
    //echo $row["id"];
    $image1 = "product_image/".$row["image1"];
    $product_brand = $row["product_brand"];
    $product_price = $row["product_price"];
    $product_title = $row["product_title"];
    $long_description = $row["long_description"];

    if($i%4==0)
    {       $data.='<div class="col-md-3 col-xs-6 text-center">
                <div class="product-cnt  border-right">
                    <div class="post-image">
                        <div class="post-heading">
                            <small>Free shipping & free returns + 2% cashback</small>
                        </div>
                        <img src='.$image1.' class="img-responsive img-fluid" alt="" width="175" />
                        <div class="container-desp">
                            <div class="text-left"><b> <a href="#">'.$product_brand.'</a> </b></div>
                            <div class="text-left"><small>'.$product_title.'</small></div>

                            <div><span class="pull-left"><small>'.$product_price.'</small></span> <span class="pull-right">
                                    <i class="far fa-heart" id="myBtn"></i>
                                </span>
                            </div>
                        </div>

                        <div id="myModal" class="modal">
                            <!-- Modal content -->
                            <div class="modal-content">
                                <span class="close"><img src="img/close-button.svg" witdt="16px" height="16px" /></span>
                                <p><b>COLOR: </b> <span id="colorselectors">
                                        <select id="colorselector_1">
                                            <option value="106" data-color="#A0522D">sienna</option>
                                            <option value="47" data-color="#CD5C5C" selected="selected">indianred</option>
                                            <option value="87" data-color="#FF4500">orangered</option>
                                            <option value="17" data-color="#008B8B">darkcyan</option>
                                        </select>
                                    </span></p>
                                <p><b>SIZE:</b> <span class="sizes">xxs </span> <span class="sizes">xxs </span> <span class="sizes">m </span> <span class="sizes">l </span> <span class="sizes">s </span></p>
                                <p><span class="buynow pull-left">Buy Now</span>
                                    <span class="addtocart pull-right">Add To <i class="fas fa-heart"></i></span> </p>
                            </div>
                        </div>
                    </div>
                </div>
                </div>';    
            $data.='</div><div class="row">';    
    }
    else
    {   $data.='<div class="col-md-3 col-xs-6 text-center">
                <div class="product-cnt  border-right">
                    <div class="post-image">
                        <div class="post-heading">
                            <small>Free shipping & free returns + 2% cashback</small>
                        </div>
                        <img src='.$image1.' class="img-responsive img-fluid" alt="" width="175" />
                        <div class="container-desp">
                            <div class="text-left"><b> <a href="#">'.$product_brand.'</a> </b></div>
                            <div class="text-left"><small>'.$product_title.'</small></div>

                            <div><span class="pull-left"><small>$'.$product_price.'</small></span> <span class="pull-right">
                                    <i class="far fa-heart" id="myBtn"></i>
                                </span>
                            </div>
                        </div>

                        <div id="myModal" class="modal">
                            <!-- Modal content -->
                            <div class="modal-content">
                                <span class="close"><img src="img/close-button.svg" witdt="16px" height="16px" /></span>
                                <p><b>COLOR: </b> <span id="colorselectors">
                                        <select id="colorselector_1">
                                            <option value="106" data-color="#A0522D">sienna</option>
                                            <option value="47" data-color="#CD5C5C" selected="selected">indianred</option>
                                            <option value="87" data-color="#FF4500">orangered</option>
                                            <option value="17" data-color="#008B8B">darkcyan</option>
                                        </select>
                                    </span></p>
                                <p><b>SIZE:</b> <span class="sizes">xxs </span> <span class="sizes">xxs </span> <span class="sizes">m </span> <span class="sizes">l </span> <span class="sizes">s </span></p>
                                <p><span class="buynow pull-left">Buy Now</span>
                                    <span class="addtocart pull-right">Add To <i class="fas fa-heart"></i></span> </p>
                            </div>
                        </div>
                    </div>
                </div>
                </div>';    
    }

    $i++;     
} 


<?php   /*
while ($row = mysqli_fetch_assoc($rs_result)) {
?>  
            <tr>  
            <td><?php echo $row["employee_name"]; ?></td>  
            <td><?php echo $row["employee_salary"]; ?></td>  
			<td><?php echo $row["employee_age"]; ?></td>  
            </tr>  
<?php  
};  */
?>
