<?php
                                    $sql0 = "SELECT * FROM categories where parent_id='0' ORDER BY categories_id"; 
                                    $rs_result0 = mysqli_query($conn, $sql0); 
                                    
                                    $data='';
                                     $i=1;
                                    echo '<li>';
                                    while ($row0 = mysqli_fetch_assoc($rs_result0)) 
                                    {
                                        $categories_id = $row0["categories_id"];
                                        $parent_id = $row0["parent_id"];
                                        $categories_name = $row0["categories_name"];
                                        
                                        $PCdata='<span>'.$categories_name.'</span>';
                                        // get subcategory    
                                       $sql2 = "SELECT * FROM categories where parent_id='.$categories_id.' ORDER BY categories_id ";  
                                        $rs_result2 = mysqli_query($conn, $sql2); 
                                        $SCdata='';
                                        $SCdata2='';
                                        $SCdata3='';
                                        while ($row2 = mysqli_fetch_assoc($rs_result2)) 
                                        {
                                            $categories_id2 = $row2["categories_id"];
                                            $parent_id = $row2["parent_id"];
                                            $categories_name2 = $row2["categories_name"];
                                            $SCdata2= '<div class="dropdown">
                                            <div class="dd-inner">
                                                <ul class="column">';
                                            $SCdata.='<li><h3>'.$categories_name2.'</h3></li>';    


                                            /*$sql3 = "SELECT * FROM categories where parent_id='.$$categories_id2.' ORDER BY id ASC LIMIT ";  
                                            $rs_result3 = mysqli_query($conn, $sql3); 
                                            $SSdata='';
                                            while ($row3 = mysqli_fetch_assoc($rs_result3)) 
                                            {
                                                $categories_id3 = $row3["categories_id"];
                                                $categories_name2 = $row2["categories_name"];
                                                $SSdata.='<li><a href="#">'.$categories_name2.'</a></li>'; 
                                            } */

                                            $SCdata3="</ul></div></div>";
                                        }

                                        echo $PCdata.$SCdata2.$SCdata.$SCdata3;
                                    }                                          
                                    ?>